use std::sync::Mutex;
use percent_encoding::percent_decode_str;
use tauri::{Emitter, Manager};
#[cfg(desktop)]
use tauri::menu::{Menu, Submenu, PredefinedMenuItem, MenuItem};

// ── Android content URI reading (JNI) ────────────────────────────────────
// On Android, files opened via intents use content:// URIs. These cannot be
// read with std::fs — we must go through Android's ContentResolver via JNI.

#[derive(serde::Serialize)]
struct ContentUriResult {
    content: String,
    filename: String,
}

#[tauri::command]
fn read_content_uri(uri: String) -> Result<ContentUriResult, String> {
    #[cfg(target_os = "android")]
    {
        android_read_content_uri(&uri)
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = uri;
        Err("Content URI reading is only supported on Android".to_string())
    }
}

#[cfg(target_os = "android")]
fn android_read_content_uri(uri_str: &str) -> Result<ContentUriResult, String> {
    use jni::objects::{JObject, JString, JValue};
    use jni::JavaVM;

    let ctx = ndk_context::android_context();
    let vm = unsafe { JavaVM::from_raw(ctx.vm().cast()) }
        .map_err(|e| format!("Failed to get JVM: {}", e))?;
    let mut env = vm.attach_current_thread()
        .map_err(|e| format!("Failed to attach JNI thread: {}", e))?;
    let activity = unsafe { JObject::from_raw(ctx.context().cast()) };

    // Parse URI string → android.net.Uri
    let uri_jstr = env.new_string(uri_str)
        .map_err(|e| format!("JNI new_string: {}", e))?;
    let uri_obj = env.call_static_method(
        "android/net/Uri", "parse",
        "(Ljava/lang/String;)Landroid/net/Uri;",
        &[JValue::Object(&JObject::from(uri_jstr))],
    ).map_err(|e| format!("Uri.parse: {}", e))?
     .l().map_err(|e| format!("Uri.parse cast: {}", e))?;

    // Get ContentResolver
    let resolver = env.call_method(
        &activity, "getContentResolver",
        "()Landroid/content/ContentResolver;", &[],
    ).map_err(|e| format!("getContentResolver: {}", e))?
     .l().map_err(|e| format!("resolver cast: {}", e))?;

    // ── Query display name via Cursor ────────────────────────────────
    let mut filename = android_query_display_name(&mut env, &resolver, &uri_obj)
        .unwrap_or_else(|| extract_filename_from_uri(uri_str));

    // If display name has no file extension, query MIME type and append one.
    // Some Android content providers return display names without extensions.
    if !filename.contains('.') {
        if let Some(ext) = android_query_mime_extension(&mut env, &resolver, &uri_obj) {
            filename = format!("{}.{}", filename, ext);
            eprintln!("[content-uri] Added extension from MIME: {}", filename);
        }
    }

    // ── Read content via InputStream + Scanner ───────────────────────
    let input_stream = env.call_method(
        &resolver, "openInputStream",
        "(Landroid/net/Uri;)Ljava/io/InputStream;",
        &[JValue::Object(&uri_obj)],
    ).map_err(|e| format!("openInputStream: {}", e))?
     .l().map_err(|e| format!("openInputStream cast: {}", e))?;

    if input_stream.is_null() {
        return Err("ContentResolver.openInputStream returned null".to_string());
    }

    // Scanner(inputStream).useDelimiter("\\A").next() reads the entire stream
    let scanner = env.new_object(
        "java/util/Scanner",
        "(Ljava/io/InputStream;)V",
        &[JValue::Object(&input_stream)],
    ).map_err(|e| format!("new Scanner: {}", e))?;

    let delim = env.new_string("\\A")
        .map_err(|e| format!("delim string: {}", e))?;
    let _ = env.call_method(
        &scanner, "useDelimiter",
        "(Ljava/lang/String;)Ljava/util/Scanner;",
        &[JValue::Object(&JObject::from(delim))],
    ).map_err(|e| format!("useDelimiter: {}", e))?;

    let has_next = env.call_method(&scanner, "hasNext", "()Z", &[])
        .map_err(|e| format!("hasNext: {}", e))?
        .z().map_err(|e| format!("hasNext cast: {}", e))?;

    let content = if has_next {
        let result_obj = env.call_method(&scanner, "next", "()Ljava/lang/String;", &[])
            .map_err(|e| format!("next: {}", e))?
            .l().map_err(|e| format!("next cast: {}", e))?;
        let jstr: JString = result_obj.into();
        let java_str = env.get_string(&jstr)
            .map_err(|e| format!("get_string: {}", e))?;
        java_str.to_string_lossy().into_owned()
    } else {
        String::new()
    };

    let _ = env.call_method(&scanner, "close", "()V", &[]);

    eprintln!("[content-uri] Read {} chars, filename: {}", content.len(), filename);
    Ok(ContentUriResult { content, filename })
}

#[cfg(target_os = "android")]
fn android_query_display_name(
    env: &mut jni::JNIEnv,
    resolver: &jni::objects::JObject,
    uri: &jni::objects::JObject,
) -> Option<String> {
    use jni::objects::{JObject, JValue};

    // Create projection array: ["_display_name"]
    let col_name = env.new_string("_display_name").ok()?;
    let string_class = env.find_class("java/lang/String").ok()?;
    let projection = env.new_object_array(1, &string_class, &JObject::from(col_name)).ok()?;

    // query(uri, projection, null, null, null)
    let cursor = env.call_method(
        resolver, "query",
        "(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;",
        &[
            JValue::Object(uri),
            JValue::Object(&JObject::from(projection)),
            JValue::Object(&JObject::null()),
            JValue::Object(&JObject::null()),
            JValue::Object(&JObject::null()),
        ],
    ).ok()?.l().ok()?;

    if cursor.is_null() { return None; }

    let has_first = env.call_method(&cursor, "moveToFirst", "()Z", &[])
        .ok()?.z().ok()?;
    if !has_first {
        let _ = env.call_method(&cursor, "close", "()V", &[]);
        return None;
    }

    let name_obj = env.call_method(
        &cursor, "getString", "(I)Ljava/lang/String;",
        &[JValue::Int(0)],
    ).ok()?.l().ok()?;
    let _ = env.call_method(&cursor, "close", "()V", &[]);

    if name_obj.is_null() { return None; }

    let name_jstr: jni::objects::JString = name_obj.into();
    let java_str = env.get_string(&name_jstr).ok()?;
    let result = java_str.to_string_lossy().into_owned();
    if result.is_empty() { None } else { Some(result) }
}

/// Query the MIME type from ContentResolver and map it to a file extension.
/// Returns None if the MIME type can't be determined or doesn't map to a known extension.
#[cfg(target_os = "android")]
fn android_query_mime_extension(
    env: &mut jni::JNIEnv,
    resolver: &jni::objects::JObject,
    uri: &jni::objects::JObject,
) -> Option<String> {
    use jni::objects::{JObject, JValue};

    // resolver.getType(uri) → String (MIME type)
    let mime_obj = env.call_method(
        resolver, "getType",
        "(Landroid/net/Uri;)Ljava/lang/String;",
        &[JValue::Object(uri)],
    ).ok()?.l().ok()?;

    if mime_obj.is_null() { return None; }

    let jstr: jni::objects::JString = mime_obj.into();
    let mime = env.get_string(&jstr).ok()?.to_string_lossy().into_owned();
    eprintln!("[content-uri] MIME type: {}", mime);

    // Map common MIME types to file extensions
    match mime.as_str() {
        "application/xml" | "text/xml" => Some("fdx".to_string()),
        "application/json" => Some("odraft".to_string()),
        "text/plain" => Some("txt".to_string()),
        "text/fountain" => Some("fountain".to_string()),
        "application/pdf" => Some("pdf".to_string()),
        _ => {
            // Try the sub-type as extension (e.g. "application/fdx" → "fdx")
            mime.rsplit('/').next().map(|s| s.to_string())
        }
    }
}

/// Read the data URI from the Android Activity's launching intent.
/// Called during setup to detect file-association cold starts on Android.
#[cfg(target_os = "android")]
fn android_get_intent_data() -> Option<String> {
    use jni::objects::JObject;
    use jni::JavaVM;

    // ndk_context::android_context() panics with "android context was not
    // initialized" when called before tao's Android glue has registered the
    // JNI VM. That race shows up on cold start under some NDK/Tauri builds
    // and brings the whole app down. Treat a missing context as "no pending
    // file" — file-association handling is opportunistic.
    let ctx = std::panic::catch_unwind(|| ndk_context::android_context()).ok()?;
    let vm = unsafe { JavaVM::from_raw(ctx.vm().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    let activity = unsafe { JObject::from_raw(ctx.context().cast()) };

    // activity.getIntent()
    let intent = env.call_method(&activity, "getIntent", "()Landroid/content/Intent;", &[])
        .ok()?.l().ok()?;
    if intent.is_null() { return None; }

    // intent.getData()
    let data = env.call_method(&intent, "getData", "()Landroid/net/Uri;", &[])
        .ok()?.l().ok()?;
    if data.is_null() { return None; }

    // uri.toString()
    let uri_obj = env.call_method(&data, "toString", "()Ljava/lang/String;", &[])
        .ok()?.l().ok()?;
    if uri_obj.is_null() { return None; }

    let jstr: jni::objects::JString = uri_obj.into();
    let java_str = env.get_string(&jstr).ok()?;
    let uri_string = java_str.to_string_lossy().into_owned();

    if uri_string.is_empty() { return None; }
    eprintln!("[file-assoc] Android intent data URI: {}", uri_string);
    Some(uri_string)
}

/// Extract a filename from a content:// URI string as fallback.
#[cfg(target_os = "android")]
fn extract_filename_from_uri(uri: &str) -> String {
    // Try to get the last path segment that looks like a filename
    if let Some(path) = uri.split('?').next() {
        if let Some(segment) = path.rsplit('/').next() {
            let decoded = percent_decode_str(segment).decode_utf8_lossy().to_string();
            if decoded.contains('.') {
                return decoded;
            }
        }
    }
    "Untitled.fdx".to_string()
}

// ── Android share sheet ──────────────────────────────────────────────────
// On Android, the Tauri save dialog doesn't work reliably (similar to iOS).
// Instead, we write to the cache directory and present an Android share
// intent so the user can save to Files, share via any app, etc.

/// Android export: write file to cache, then present a "Save As" document picker
/// via ACTION_CREATE_DOCUMENT.  The user picks a location and Android copies the
/// content from our temp file to the chosen URI via ContentResolver.
///
/// Falls back to ACTION_SEND share sheet if CREATE_DOCUMENT fails (e.g. no
/// document provider is available on the device).
#[cfg(target_os = "android")]
fn android_share_file(file_path: &str, mime_type: &str) -> Result<(), String> {
    use jni::objects::{JObject, JValue};
    use jni::JavaVM;

    let ctx = ndk_context::android_context();
    let vm = unsafe { JavaVM::from_raw(ctx.vm().cast()) }
        .map_err(|e| format!("Failed to get JVM: {}", e))?;
    let mut env = vm.attach_current_thread()
        .map_err(|e| format!("Failed to attach JNI thread: {}", e))?;
    let activity = unsafe { JObject::from_raw(ctx.context().cast()) };

    // Store the temp file path so onActivityResult can copy it to the user's chosen location
    let path_jstr = env.new_string(file_path)
        .map_err(|e| format!("JNI new_string: {}", e))?;
    env.call_static_method(
        "com/proteus/opendraft/MainActivity",
        "setExportSourcePath",
        "(Ljava/lang/String;)V",
        &[JValue::Object(&JObject::from(path_jstr))],
    ).map_err(|e| format!("setExportSourcePath: {}", e))?;

    // Extract filename from path
    let filename = file_path.rsplit('/').next().unwrap_or("export");

    // Create Intent(ACTION_CREATE_DOCUMENT) — Android's native "Save As" dialog
    let action_str = env.new_string("android.intent.action.CREATE_DOCUMENT")
        .map_err(|e| format!("JNI new_string: {}", e))?;
    let intent = env.new_object("android/content/Intent", "(Ljava/lang/String;)V",
        &[JValue::Object(&JObject::from(action_str))])
        .map_err(|e| format!("new Intent: {}", e))?;

    // intent.addCategory(CATEGORY_OPENABLE)
    let cat_str = env.new_string("android.intent.category.OPENABLE")
        .map_err(|e| format!("JNI new_string: {}", e))?;
    let _ = env.call_method(&intent, "addCategory",
        "(Ljava/lang/String;)Landroid/content/Intent;",
        &[JValue::Object(&JObject::from(cat_str))])
        .map_err(|e| format!("addCategory: {}", e))?;

    // intent.setType(mimeType)
    let mime = env.new_string(mime_type)
        .map_err(|e| format!("JNI new_string: {}", e))?;
    let _ = env.call_method(&intent, "setType",
        "(Ljava/lang/String;)Landroid/content/Intent;",
        &[JValue::Object(&JObject::from(mime))])
        .map_err(|e| format!("setType: {}", e))?;

    // intent.putExtra(EXTRA_TITLE, filename) — suggested filename
    let extra_title = env.new_string("android.intent.extra.TITLE")
        .map_err(|e| format!("JNI new_string: {}", e))?;
    let filename_jstr = env.new_string(filename)
        .map_err(|e| format!("JNI new_string: {}", e))?;
    let _ = env.call_method(&intent, "putExtra",
        "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;",
        &[
            JValue::Object(&JObject::from(extra_title)),
            JValue::Object(&JObject::from(filename_jstr)),
        ])
        .map_err(|e| format!("putExtra TITLE: {}", e))?;

    // activity.startActivityForResult(intent, EXPORT_FILE_REQUEST=43)
    env.call_method(&activity, "startActivityForResult",
        "(Landroid/content/Intent;I)V",
        &[JValue::Object(&intent), JValue::Int(43)])
        .map_err(|e| format!("startActivityForResult: {}", e))?;

    eprintln!("[export] Launched save-as picker for {}", filename);
    Ok(())
}

#[tauri::command]
fn android_save_and_share(filename: String, contents: String) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let cache_dir = std::env::temp_dir();
        let path = cache_dir.join(&filename);
        std::fs::write(&path, &contents)
            .map_err(|e| format!("Failed to write temp file: {}", e))?;
        // Use application/octet-stream so Android's save-as dialog
        // preserves the exact filename without appending an extension
        android_share_file(&path.to_string_lossy(), "application/octet-stream")
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = (filename, contents);
        Err("This command is only available on Android".to_string())
    }
}

#[tauri::command]
fn android_save_and_share_binary(filename: String, contents: Vec<u8>) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let cache_dir = std::env::temp_dir();
        let path = cache_dir.join(&filename);
        std::fs::write(&path, &contents)
            .map_err(|e| format!("Failed to write temp file: {}", e))?;
        let mime = if filename.ends_with(".pdf") { "application/pdf" } else { "application/octet-stream" };
        android_share_file(&path.to_string_lossy(), mime)
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = (filename, contents);
        Err("This command is only available on Android".to_string())
    }
}

// ── Android native file picker ──────────────────────────────────────────
// Launches ACTION_OPEN_DOCUMENT intent so the user can pick a file.
// The result is captured by MainActivity.onActivityResult() and stored in
// a static companion field, then retrieved by android_get_picked_file().

#[tauri::command]
fn android_pick_file() -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        use jni::objects::{JObject, JValue};
        use jni::JavaVM;

        let ctx = ndk_context::android_context();
        let vm = unsafe { JavaVM::from_raw(ctx.vm().cast()) }
            .map_err(|e| format!("Failed to get JVM: {}", e))?;
        let mut env = vm.attach_current_thread()
            .map_err(|e| format!("Failed to attach JNI thread: {}", e))?;
        let activity = unsafe { JObject::from_raw(ctx.context().cast()) };

        // Clear any previous picked file URI
        let null_obj = JObject::null();
        let _ = env.call_static_method(
            "com/proteus/opendraft/MainActivity",
            "setPickedFileUri",
            "(Ljava/lang/String;)V",
            &[JValue::Object(&null_obj)],
        );

        // Create Intent(ACTION_OPEN_DOCUMENT)
        let action_str = env.new_string("android.intent.action.OPEN_DOCUMENT")
            .map_err(|e| format!("JNI new_string: {}", e))?;
        let intent = env.new_object(
            "android/content/Intent",
            "(Ljava/lang/String;)V",
            &[JValue::Object(&JObject::from(action_str))],
        ).map_err(|e| format!("new Intent: {}", e))?;

        // intent.addCategory(CATEGORY_OPENABLE)
        let cat_str = env.new_string("android.intent.category.OPENABLE")
            .map_err(|e| format!("JNI new_string: {}", e))?;
        let _ = env.call_method(
            &intent, "addCategory",
            "(Ljava/lang/String;)Landroid/content/Intent;",
            &[JValue::Object(&JObject::from(cat_str))],
        ).map_err(|e| format!("addCategory: {}", e))?;

        // intent.setType("*/*") — accept all file types
        let mime_str = env.new_string("*/*")
            .map_err(|e| format!("JNI new_string: {}", e))?;
        let _ = env.call_method(
            &intent, "setType",
            "(Ljava/lang/String;)Landroid/content/Intent;",
            &[JValue::Object(&JObject::from(mime_str))],
        ).map_err(|e| format!("setType: {}", e))?;

        // activity.startActivityForResult(intent, PICK_FILE_REQUEST=42)
        env.call_method(
            &activity, "startActivityForResult",
            "(Landroid/content/Intent;I)V",
            &[JValue::Object(&intent), JValue::Int(42)],
        ).map_err(|e| format!("startActivityForResult: {}", e))?;

        eprintln!("[file-picker] Launched document picker");
        Ok(())
    }
    #[cfg(not(target_os = "android"))]
    {
        Err("This command is only available on Android".to_string())
    }
}

/// Read and clear the picked file URI from the Activity's companion object.
/// Returns the content URI string, empty string if cancelled, or None if
/// the picker hasn't returned yet.
#[tauri::command]
fn android_get_picked_file() -> Option<String> {
    #[cfg(target_os = "android")]
    {
        android_read_and_clear_companion_field("getPickedFileUri", "setPickedFileUri")
    }
    #[cfg(not(target_os = "android"))]
    {
        None
    }
}

/// Check for a new intent URI from a warm-start "Open with" action.
/// Reads and clears newIntentUri from the Activity companion object,
/// and updates the PendingFile state so get_opened_file stays in sync.
#[tauri::command]
fn android_check_new_intent(state: tauri::State<PendingFile>) -> Option<String> {
    #[cfg(target_os = "android")]
    {
        let uri = android_read_and_clear_companion_field("getNewIntentUri", "setNewIntentUri");
        if let Some(ref u) = uri {
            eprintln!("[file-assoc] New intent detected: {}", u);
            // Update PendingFile so get_opened_file returns this URI
            *state.0.lock().unwrap() = Some(u.clone());
        }
        uri
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = state;
        None
    }
}

/// Helper: read a String? from a static getter on MainActivity and clear it via the setter.
#[cfg(target_os = "android")]
fn android_read_and_clear_companion_field(getter: &str, setter: &str) -> Option<String> {
    use jni::objects::{JObject, JString, JValue};
    use jni::JavaVM;

    let ctx = ndk_context::android_context();
    let vm = unsafe { JavaVM::from_raw(ctx.vm().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;

    let result = env.call_static_method(
        "com/proteus/opendraft/MainActivity",
        getter,
        "()Ljava/lang/String;",
        &[],
    ).ok()?.l().ok()?;

    if result.is_null() {
        return None;
    }

    let jstr: JString = result.into();
    let value = env.get_string(&jstr).ok()?.to_string_lossy().into_owned();

    // Clear the field
    let null_obj = JObject::null();
    let _ = env.call_static_method(
        "com/proteus/opendraft/MainActivity",
        setter,
        "(Ljava/lang/String;)V",
        &[JValue::Object(&null_obj)],
    );

    // Return Some even for empty string (signals cancellation for file picker)
    Some(value)
}

// ── iOS file helpers (Objective-C FFI) ────────────────────────────────────
// On iOS, files from the Files app or document picker require security-scoped
// URL access. These functions are defined in FileHelpers.m and linked into
// the iOS binary automatically via XcodeGen.

#[cfg(target_os = "ios")]
extern "C" {
    fn ios_present_share_sheet(file_path: *const std::ffi::c_char);
    fn ios_read_text_file(path: *const std::ffi::c_char) -> *mut std::ffi::c_char;
    fn ios_free_string(ptr: *mut std::ffi::c_char);
    fn ios_copy_file_scoped(src: *const std::ffi::c_char, dst: *const std::ffi::c_char) -> i32;
}

// ── iOS export commands ──────────────────────────────────────────────────
// On iOS, the native save dialog doesn't work reliably (files end up 0 bytes).
// Instead, we write to a temp file and present the iOS share sheet so the user
// can save to Files, AirDrop, etc.

#[tauri::command]
fn ios_save_and_share(filename: String, contents: String) -> Result<(), String> {
    #[cfg(target_os = "ios")]
    {
        let temp_dir = std::env::temp_dir();
        let path = temp_dir.join(&filename);
        std::fs::write(&path, &contents)
            .map_err(|e| format!("Failed to write temp file: {}", e))?;
        let c_path = std::ffi::CString::new(path.to_string_lossy().as_bytes())
            .map_err(|e| format!("Invalid path: {}", e))?;
        unsafe { ios_present_share_sheet(c_path.as_ptr()); }
        Ok(())
    }
    #[cfg(not(target_os = "ios"))]
    {
        let _ = (filename, contents);
        Err("This command is only available on iOS".to_string())
    }
}

#[tauri::command]
fn ios_save_and_share_binary(filename: String, contents: Vec<u8>) -> Result<(), String> {
    #[cfg(target_os = "ios")]
    {
        let temp_dir = std::env::temp_dir();
        let path = temp_dir.join(&filename);
        std::fs::write(&path, &contents)
            .map_err(|e| format!("Failed to write temp file: {}", e))?;
        let c_path = std::ffi::CString::new(path.to_string_lossy().as_bytes())
            .map_err(|e| format!("Invalid path: {}", e))?;
        unsafe { ios_present_share_sheet(c_path.as_ptr()); }
        Ok(())
    }
    #[cfg(not(target_os = "ios"))]
    {
        let _ = (filename, contents);
        Err("This command is only available on iOS".to_string())
    }
}

// ── Pending file state ────────────────────────────────────────────────────
// Stores the file path when the OS opens a screenplay file with OpenDraft.
// The frontend retrieves it on startup via the get_opened_file command.
struct PendingFile(Mutex<Option<String>>);

/// Extensions that OpenDraft can open via file association.
const OPENABLE_EXTENSIONS: &[&str] = &["fdx", "fountain", "odraft", "txt"];

fn is_openable_file(path: &str) -> bool {
    let ext = path.rsplit('.').next().unwrap_or("");
    OPENABLE_EXTENSIONS.contains(&ext.to_lowercase().as_str())
}

#[tauri::command]
fn get_opened_file(state: tauri::State<PendingFile>) -> Option<String> {
    state.0.lock().unwrap().clone()
}

// ── File I/O commands ──────────────────────────────────────────────────────
// These bypass the fs plugin scope so the user can save/open files anywhere
// via the native dialog.

#[tauri::command]
fn save_text_to_path(path: String, contents: String) -> Result<(), String> {
    std::fs::write(&path, contents).map_err(|e| format!("Failed to write {}: {}", path, e))
}

#[tauri::command]
fn save_binary_to_path(path: String, contents: Vec<u8>) -> Result<(), String> {
    std::fs::write(&path, contents).map_err(|e| format!("Failed to write {}: {}", path, e))
}

#[tauri::command]
fn read_text_file(path: String) -> Result<String, String> {
    #[cfg(not(target_os = "ios"))]
    {
        std::fs::read_to_string(&path).map_err(|e| format!("Failed to read {}: {}", path, e))
    }
    #[cfg(target_os = "ios")]
    {
        // Try standard read first (works for files already in the sandbox)
        if let Ok(content) = std::fs::read_to_string(&path) {
            return Ok(content);
        }
        // Fallback: try reading via Foundation APIs with security-scoped access
        eprintln!("[read_text_file] std::fs failed, trying iOS security-scoped read: {}", path);
        let c_path = std::ffi::CString::new(path.as_bytes())
            .map_err(|_| format!("Invalid path: {}", path))?;
        let result = unsafe { ios_read_text_file(c_path.as_ptr()) };
        if result.is_null() {
            return Err(format!("Failed to read {}: Operation not permitted", path));
        }
        let content = unsafe { std::ffi::CStr::from_ptr(result) }
            .to_string_lossy()
            .into_owned();
        unsafe { ios_free_string(result); }
        Ok(content)
    }
}

#[tauri::command]
fn read_binary_file(path: String) -> Result<Vec<u8>, String> {
    std::fs::read(&path).map_err(|e| format!("Failed to read {}: {}", path, e))
}

// ── Generic HTTP fetch command ────────────────────────────────────────────
// Makes HTTP requests from Rust, bypassing WebView mixed-content restrictions.
// The Tauri WebView loads from https://tauri.localhost, so browser fetch() to
// plain http:// addresses (collab server, local backends) is blocked.

#[derive(serde::Serialize)]
struct HttpFetchResponse {
    status: u16,
    body: String,
}

#[tauri::command]
async fn http_fetch(
    url: String,
    method: Option<String>,
    body: Option<String>,
    content_type: Option<String>,
    authorization: Option<String>,
) -> Result<HttpFetchResponse, String> {
    let method_str = method.as_deref().unwrap_or("GET");
    eprintln!("[http_fetch] {} {}", method_str, url);

    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(10))
        .build()
        .map_err(|e| {
            eprintln!("[http_fetch] Client build error: {}", e);
            format!("HTTP client error: {}", e)
        })?;

    let req_method = method_str.parse::<reqwest::Method>()
        .map_err(|e| format!("Invalid method '{}': {}", method_str, e))?;

    let mut req = client.request(req_method, &url);

    if let Some(ct) = &content_type {
        req = req.header("Content-Type", ct.as_str());
    }

    if let Some(auth) = &authorization {
        req = req.header("Authorization", auth.as_str());
    }

    if let Some(b) = &body {
        req = req.body(b.clone());
    }

    let resp = req.send().await
        .map_err(|e| {
            eprintln!("[http_fetch] {} {} → FAILED: {}", method_str, url, e);
            format!("Request to {} failed: {}", url, e)
        })?;

    let status = resp.status().as_u16();
    let body_text = resp.text().await
        .map_err(|e| format!("Failed to read response body: {}", e))?;

    eprintln!("[http_fetch] {} {} → {} ({} bytes)", method_str, url, status, body_text.len());

    Ok(HttpFetchResponse {
        status,
        body: body_text,
    })
}

// ── Link preview command ───────────────────────────────────────────────────
// Fetches a URL and extracts Open Graph metadata. Used by the editor's link
// preview feature. Runs in Rust to avoid CORS issues that browser fetch has.

#[derive(serde::Serialize)]
struct LinkPreview {
    url: String,
    title: String,
    description: String,
    image: String,
    site_name: String,
}

#[tauri::command]
async fn fetch_link_preview(url: String) -> Result<LinkPreview, String> {
    let html = fetch_url_body(&url).await.map_err(|e| format!("Failed to fetch {}: {}", url, e))?;

    let title = extract_og_tag(&html, "og:title")
        .or_else(|| extract_html_title(&html))
        .unwrap_or_default();
    let description = extract_og_tag(&html, "og:description")
        .or_else(|| extract_meta_description(&html))
        .unwrap_or_default();
    let image = extract_og_tag(&html, "og:image").unwrap_or_default();
    let site_name = extract_og_tag(&html, "og:site_name").unwrap_or_default();

    Ok(LinkPreview { url, title, description, image, site_name })
}

/// Fetch URL body using reqwest (works on all platforms including iOS/Android).
/// Times out after 5 seconds.
async fn fetch_url_body(url: &str) -> Result<String, Box<dyn std::error::Error>> {
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(5))
        .user_agent("Mozilla/5.0 (compatible; OpenDraft/1.0)")
        .build()?;

    let resp = client.get(url).send().await?;
    let body = resp.text().await?;
    Ok(body)
}

/// Extract an Open Graph meta tag value from HTML.
fn extract_og_tag(html: &str, property: &str) -> Option<String> {
    // Match: <meta property="og:title" content="...">
    // Also match: <meta content="..." property="og:title">
    let lower = html.to_lowercase();
    let prop_pattern = format!("property=\"{}\"", property);

    // Find the meta tag containing this property
    let mut search_from = 0;
    while let Some(meta_start) = lower[search_from..].find("<meta ") {
        let abs_start = search_from + meta_start;
        let tag_end = match lower[abs_start..].find('>') {
            Some(pos) => abs_start + pos,
            None => break,
        };
        let tag = &html[abs_start..=tag_end];
        let tag_lower = &lower[abs_start..=tag_end];

        if tag_lower.contains(&prop_pattern) {
            if let Some(content) = extract_attr(tag, "content") {
                return Some(decode_html_entities(&content));
            }
        }
        search_from = tag_end + 1;
    }
    None
}

/// Extract the <title> tag content.
fn extract_html_title(html: &str) -> Option<String> {
    let lower = html.to_lowercase();
    let start = lower.find("<title")?.checked_add(lower[lower.find("<title")?..].find('>')?)?;
    let content_start = start + 1;
    let end = lower[content_start..].find("</title>")?;
    let title = html[content_start..content_start + end].trim();
    if title.is_empty() { None } else { Some(decode_html_entities(title)) }
}

/// Extract <meta name="description" content="...">.
fn extract_meta_description(html: &str) -> Option<String> {
    let lower = html.to_lowercase();
    let mut search_from = 0;
    while let Some(meta_start) = lower[search_from..].find("<meta ") {
        let abs_start = search_from + meta_start;
        let tag_end = match lower[abs_start..].find('>') {
            Some(pos) => abs_start + pos,
            None => break,
        };
        let tag = &html[abs_start..=tag_end];
        let tag_lower = &lower[abs_start..=tag_end];

        if tag_lower.contains("name=\"description\"") {
            if let Some(content) = extract_attr(tag, "content") {
                return Some(decode_html_entities(&content));
            }
        }
        search_from = tag_end + 1;
    }
    None
}

/// Extract an HTML attribute value (case-insensitive attribute name).
fn extract_attr(tag: &str, attr_name: &str) -> Option<String> {
    let lower = tag.to_lowercase();
    let pattern = format!("{}=\"", attr_name);
    let start = lower.find(&pattern)? + pattern.len();
    let end = lower[start..].find('"')? + start;
    Some(tag[start..end].to_string())
}

/// Decode common HTML entities.
fn decode_html_entities(s: &str) -> String {
    s.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
}

/// Guess MIME type from file extension.
fn guess_mime(path: &std::path::Path) -> &'static str {
    match path.extension().and_then(|e| e.to_str()).map(|e| e.to_lowercase()).as_deref() {
        Some("jpg") | Some("jpeg") => "image/jpeg",
        Some("png") => "image/png",
        Some("gif") => "image/gif",
        Some("webp") => "image/webp",
        Some("svg") => "image/svg+xml",
        Some("bmp") => "image/bmp",
        Some("ico") => "image/x-icon",
        Some("pdf") => "application/pdf",
        Some("mp4") => "video/mp4",
        Some("webm") => "video/webm",
        Some("mp3") => "audio/mpeg",
        Some("wav") => "audio/wav",
        Some("ogg") => "audio/ogg",
        Some("json") => "application/json",
        Some("txt") => "text/plain",
        _ => "application/octet-stream",
    }
}

// ── New window command (for multi-instance support) ──────────────────────
// Each WebviewWindow gets its own JS context, so editor state is independent.
use std::sync::atomic::{AtomicU32, AtomicBool, Ordering};
static WINDOW_COUNTER: AtomicU32 = AtomicU32::new(1);
/// Set to true once the main window has finished loading.
/// Used to distinguish cold-start file opens (load into main window)
/// from warm-start file opens (open in a new window).
static APP_READY: AtomicBool = AtomicBool::new(false);

/// Update the native window title and refresh the Window menu list.
/// Called from the frontend whenever the document title changes.
#[tauri::command]
async fn set_window_title(window: tauri::WebviewWindow, title: String) -> Result<(), String> {
    #[cfg(desktop)]
    {
        let display_title = if title.is_empty() { "OpenDraft".to_string() } else { format!("{} — OpenDraft", title) };
        window.set_title(&display_title).map_err(|e| format!("{}", e))?;
        // Rebuild the Window menu to reflect current window titles
        let app = window.app_handle();
        if let Some(menu) = app.menu() {
            rebuild_window_menu(app, &menu);
        }
    }
    #[cfg(not(desktop))]
    { let _ = (window, title); }
    Ok(())
}

/// Open a URL in the user's default browser.
#[tauri::command]
fn open_url(url: String) -> Result<(), String> {
    // Only allow http/https URLs
    if !url.starts_with("http://") && !url.starts_with("https://") {
        return Err("Only http and https URLs are allowed".to_string());
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .arg(&url)
            .spawn()
            .map_err(|e| format!("Failed to open URL: {}", e))?;
    }
    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("cmd")
            .args(["/C", "start", "", &url])
            .spawn()
            .map_err(|e| format!("Failed to open URL: {}", e))?;
    }
    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("xdg-open")
            .arg(&url)
            .spawn()
            .map_err(|e| format!("Failed to open URL: {}", e))?;
    }
    Ok(())
}

/// Rebuild the Window menu: standard items + list of all open windows.
#[cfg(desktop)]
fn rebuild_window_menu(app: &tauri::AppHandle, _menu: &Menu<tauri::Wry>) {
    #[cfg(not(target_os = "macos"))]
    return;

    #[cfg(target_os = "macos")]
    {
        // Build a fresh Window submenu with standard items + window list
        let mut items: Vec<Box<dyn tauri::menu::IsMenuItem<tauri::Wry>>> = vec![
            Box::new(PredefinedMenuItem::minimize(app, None).unwrap()),
            Box::new(PredefinedMenuItem::maximize(app, None).unwrap()),
            Box::new(PredefinedMenuItem::separator(app).unwrap()),
            Box::new(PredefinedMenuItem::close_window(app, None).unwrap()),
        ];

        // Add all open windows
        let windows = app.webview_windows();
        let mut win_entries: Vec<_> = windows.iter()
            .filter(|(label, _)| *label != "splashscreen")
            .collect();
        win_entries.sort_by_key(|(label, _)| label.clone());

        if !win_entries.is_empty() {
            items.push(Box::new(PredefinedMenuItem::separator(app).unwrap()));
            for (label, win) in &win_entries {
                let title = win.title().unwrap_or_else(|_| (*label).clone());
                let item_id = format!("window-list-{}", label);
                if let Ok(mi) = MenuItem::with_id(app, &item_id, &title, true, None::<&str>) {
                    items.push(Box::new(mi));
                }
            }
        }

        // Convert to references for Submenu::with_items
        let item_refs: Vec<&dyn tauri::menu::IsMenuItem<tauri::Wry>> = items.iter()
            .map(|b| b.as_ref())
            .collect();

        if let Ok(new_window_sub) = Submenu::with_items(app, "Window", true, &item_refs) {
            // Replace the Window submenu in the app menu
            if let Some(menu) = app.menu() {
                // Remove old Window submenu and append new one
                if let Ok(menu_items) = menu.items() {
                    for item in &menu_items {
                        if let tauri::menu::MenuItemKind::Submenu(sub) = item {
                            if sub.text().unwrap_or_default() == "Window" {
                                let _ = menu.remove(item);
                                break;
                            }
                        }
                    }
                }
                let _ = menu.append(&new_window_sub);
            }
        }
    }
}

#[tauri::command]
async fn open_new_window(app: tauri::AppHandle) -> Result<(), String> {
    let count = WINDOW_COUNTER.fetch_add(1, Ordering::Relaxed);
    let label = format!("main-{}", count);
    // Use "/" so BrowserRouter matches the root route (not "/index.html")
    let url = tauri::WebviewUrl::App("/".into());
    let mut builder = tauri::WebviewWindowBuilder::new(&app, &label, url);
    // .title(), .inner_size(), .min_inner_size(), .resizable() are desktop-only
    #[cfg(desktop)]
    {
        builder = builder
            .title("OpenDraft")
            .inner_size(1280.0, 800.0)
            .min_inner_size(800.0, 600.0)
            .resizable(true);
    }
    builder.build()
        .map_err(|e| format!("Failed to create window: {}", e))?;
    // Refresh window list in the Window menu
    #[cfg(desktop)]
    if let Some(menu) = app.menu() {
        rebuild_window_menu(&app, &menu);
    }
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let builder = tauri::Builder::default()
        // ── Plugins (available on all platforms) ────────────────────────
        .plugin(
            tauri_plugin_sql::Builder::default()
                .build(),
        )
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_dialog::init())
        // ── Asset protocol: serve local files for convertFileSrc() URLs ──
        .register_uri_scheme_protocol("asset", |_app, request| {
            let uri = request.uri();
            let raw_path = uri.path();
            // Decode percent-encoded path and strip leading slash
            let decoded = percent_decode_str(raw_path).decode_utf8_lossy();
            let file_path_str = decoded.trim_start_matches('/');
            let file_path = std::path::Path::new(file_path_str);

            // Build a Response without unwrapping — a panic here aborts the
            // whole process because [profile.release] panic = "abort".
            let build_response = |status: u16, mime: &str, body: Vec<u8>| {
                tauri::http::Response::builder()
                    .status(status)
                    .header("Content-Type", mime)
                    .header("Access-Control-Allow-Origin", "*")
                    .body(body)
                    .unwrap_or_else(|_| {
                        tauri::http::Response::new(Vec::new())
                    })
            };
            match std::fs::read(file_path) {
                Ok(data) => build_response(200, guess_mime(file_path), data),
                Err(e) => {
                    eprintln!("[asset] Failed to read {}: {}", file_path_str, e);
                    build_response(404, "text/plain", Vec::new())
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            save_text_to_path,
            save_binary_to_path,
            read_text_file,
            read_binary_file,
            http_fetch,
            fetch_link_preview,
            get_opened_file,
            read_content_uri,
            ios_save_and_share,
            ios_save_and_share_binary,
            android_save_and_share,
            android_save_and_share_binary,
            android_pick_file,
            android_get_picked_file,
            android_check_new_intent,
            open_new_window,
            set_window_title,
            open_url,
        ]);

        // ── Native menu (desktop only) ────────────────────────────────
        // macOS: App menu + Edit menu (Cmd+C/V/X/A/Z) + Window menu.
        //        The Edit menu is required for clipboard & undo shortcuts
        //        to reach the webview on macOS.
        // Windows/Linux: empty menu — no native menu bar shown.
        // Mobile (iOS/Android): no menu support — .menu() is not available.
        #[cfg(desktop)]
        let builder = builder.menu(|app_handle| {
            #[cfg(target_os = "macos")]
            {
                let app_submenu = Submenu::with_items(
                    app_handle,
                    "OpenDraft",
                    true,
                    &[
                        &PredefinedMenuItem::about(app_handle, Some("About OpenDraft"), None)?,
                        &PredefinedMenuItem::separator(app_handle)?,
                        &PredefinedMenuItem::services(app_handle, None)?,
                        &PredefinedMenuItem::separator(app_handle)?,
                        &PredefinedMenuItem::hide(app_handle, None)?,
                        &PredefinedMenuItem::hide_others(app_handle, None)?,
                        &PredefinedMenuItem::show_all(app_handle, None)?,
                        &PredefinedMenuItem::separator(app_handle)?,
                        &PredefinedMenuItem::quit(app_handle, None)?,
                    ],
                )?;
                let edit_submenu = Submenu::with_items(
                    app_handle,
                    "Edit",
                    true,
                    &[
                        &PredefinedMenuItem::undo(app_handle, None)?,
                        &PredefinedMenuItem::redo(app_handle, None)?,
                        &PredefinedMenuItem::separator(app_handle)?,
                        &PredefinedMenuItem::cut(app_handle, None)?,
                        &PredefinedMenuItem::copy(app_handle, None)?,
                        &PredefinedMenuItem::paste(app_handle, None)?,
                        &PredefinedMenuItem::select_all(app_handle, None)?,
                    ],
                )?;
                let window_submenu = Submenu::with_items(
                    app_handle,
                    "Window",
                    true,
                    &[
                        &PredefinedMenuItem::minimize(app_handle, None)?,
                        &PredefinedMenuItem::maximize(app_handle, None)?,
                        &PredefinedMenuItem::separator(app_handle)?,
                        &PredefinedMenuItem::close_window(app_handle, None)?,
                    ],
                )?;
                Menu::with_items(app_handle, &[&app_submenu, &edit_submenu, &window_submenu])
            }
            #[cfg(not(target_os = "macos"))]
            {
                Menu::new(app_handle)
            }
        });

    let builder = builder.setup(|app| {
            // Ensure user data directory exists
            let app_data_dir = app
                .path()
                .app_data_dir()
                .expect("failed to resolve app data directory");
            std::fs::create_dir_all(&app_data_dir).ok();

            eprintln!("FreeDraft starting — local SQLite storage");
            eprintln!("Data dir: {}", app_data_dir.display());

            // ── Check for file association launch ──────────────────────────
            let mut pending: Option<String> = None;

            // Windows/Linux: check CLI args
            #[cfg(not(any(target_os = "ios", target_os = "android")))]
            {
                let args: Vec<String> = std::env::args().collect();
                if args.len() > 1 {
                    let path = &args[1];
                    if is_openable_file(path) && std::path::Path::new(path).is_file() {
                        eprintln!("File association launch: {}", path);
                        pending = Some(path.clone());
                    }
                }
            }

            // Android: check the launching intent for a data URI
            #[cfg(target_os = "android")]
            if pending.is_none() {
                if let Some(uri) = android_get_intent_data() {
                    pending = Some(uri);
                }
            }

            // Clone before moving into managed state (needed for Android re-emit)
            #[cfg(target_os = "android")]
            let android_pending = pending.clone();

            app.manage(PendingFile(Mutex::new(pending)));

            // Android: emit open-file events with delays for the JS listener
            // (RunEvent::Opened is not available on Android)
            #[cfg(target_os = "android")]
            {
                if let Some(uri) = android_pending {
                    let handle = app.handle().clone();
                    std::thread::spawn(move || {
                        for delay_ms in [500, 1500, 3000] {
                            std::thread::sleep(std::time::Duration::from_millis(delay_ms));
                            eprintln!("[file-assoc] Android re-emit open-file after {}ms", delay_ms);
                            let _ = handle.emit_to("main", "open-file", &uri);
                        }
                    });
                }
            }

            // ── Desktop: show splash then transition to main window ───
            #[cfg(not(target_os = "ios"))]
            #[cfg(not(target_os = "android"))]
            {
                let splash = app.get_webview_window("splashscreen");
                let main_window = app.get_webview_window("main");

                std::thread::spawn(move || {
                    // Brief splash display — no backend to wait for
                    std::thread::sleep(std::time::Duration::from_millis(500));

                    if let Some(main) = main_window {
                        let _ = main.show();
                        let _ = main.set_focus();
                    }
                    if let Some(sp) = splash {
                        let _ = sp.close();
                    }
                    // Mark app as ready — subsequent file opens go to new windows
                    APP_READY.store(true, Ordering::Release);
                });
            }

            Ok(())
        });

    // Handle Window menu clicks to focus the selected window
    #[cfg(desktop)]
    let builder = builder.on_menu_event(|app, event| {
        let id = event.id().0.as_str();
        if let Some(label) = id.strip_prefix("window-list-") {
            if let Some(win) = app.get_webview_window(label) {
                let _ = win.unminimize();
                let _ = win.show();
                let _ = win.set_focus();
            }
        }
    })
    .on_window_event(|window, event| {
        if let tauri::WindowEvent::Destroyed = event {
            let app = window.app_handle();
            if let Some(menu) = app.menu() {
                rebuild_window_menu(app, &menu);
            }
        }
    });

    let app = builder
        .build(tauri::generate_context!())
        .unwrap_or_else(|e| {
            let msg = format!("FATAL: Failed to build Tauri app: {}", e);
            eprintln!("{}", msg);
            let _ = std::fs::write("/tmp/opendraft_crash.log", &msg);
            panic!("{}", msg);
        });

    app.run(|_app_handle, _event| {
        // ── Handle file association open events (macOS + iOS) ──────
        // Note: Android does NOT support RunEvent::Opened — intent data is
        // handled in setup() via android_get_intent_data() instead.
        #[cfg(any(target_os = "macos", target_os = "ios"))]
        if let tauri::RunEvent::Opened { urls } = &_event {
            for url in urls {
                if let Ok(path) = url.to_file_path() {
                    let mut path_str = path.to_string_lossy().to_string();
                    if !is_openable_file(&path_str) {
                        continue;
                    }

                    // On iOS, copy the file to the app's temp directory using
                    // security-scoped access. Files from the Files app require
                    // startAccessingSecurityScopedResource before reading/copying.
                    // Files from WhatsApp etc. land in Documents/Inbox (already
                    // in sandbox) so the copy succeeds either way.
                    #[cfg(target_os = "ios")]
                    {
                        let temp_dir = std::env::temp_dir();
                        let fname = path.file_name().unwrap_or_default();
                        let temp_path = temp_dir.join(fname);
                        let c_src = std::ffi::CString::new(path_str.as_bytes()).ok();
                        let c_dst = std::ffi::CString::new(temp_path.to_string_lossy().as_bytes()).ok();
                        let copied = match (c_src, c_dst) {
                            (Some(src), Some(dst)) => unsafe {
                                ios_copy_file_scoped(src.as_ptr(), dst.as_ptr()) == 1
                            },
                            _ => false,
                        };
                        if copied {
                            eprintln!("[file-assoc] iOS: copied to sandbox temp: {}", temp_path.display());
                            path_str = temp_path.to_string_lossy().to_string();
                        } else {
                            eprintln!("[file-assoc] iOS: scoped copy failed, trying std::fs::copy");
                            match std::fs::copy(&path, &temp_path) {
                                Ok(_) => {
                                    eprintln!("[file-assoc] iOS: std::fs::copy succeeded: {}", temp_path.display());
                                    path_str = temp_path.to_string_lossy().to_string();
                                }
                                Err(e) => {
                                    eprintln!("[file-assoc] iOS: all copy attempts failed ({}), using original", e);
                                }
                            }
                        }
                    }

                    eprintln!("[file-assoc] RunEvent::Opened: {}", path_str);

                    // Desktop warm start: open file in a new window
                    #[cfg(desktop)]
                    if APP_READY.load(Ordering::Acquire) {
                        eprintln!("[file-assoc] App already running — opening in new window");
                        let count = WINDOW_COUNTER.fetch_add(1, Ordering::Relaxed);
                        let label = format!("main-{}", count);
                        let url = tauri::WebviewUrl::App("/".into());
                        match tauri::WebviewWindowBuilder::new(_app_handle, &label, url)
                            .title("OpenDraft")
                            .inner_size(1280.0, 800.0)
                            .min_inner_size(800.0, 600.0)
                            .resizable(true)
                            .build()
                        {
                            Ok(_new_win) => {
                                // Use emit_to with the label to target ONLY the new window.
                                // WebviewWindow::emit() broadcasts to all windows.
                                let handle = _app_handle.clone();
                                let target_label = label.clone();
                                let path_for_emit = path_str.clone();
                                std::thread::spawn(move || {
                                    for delay_ms in [500, 1500, 3000] {
                                        std::thread::sleep(std::time::Duration::from_millis(delay_ms));
                                        let _ = handle.emit_to(&target_label, "open-file", &path_for_emit);
                                    }
                                });
                                continue; // skip the old broadcast path
                            }
                            Err(e) => {
                                eprintln!("[file-assoc] Failed to create new window: {}", e);
                                // Fall through to old behavior
                            }
                        }
                    }

                    // Cold start / iOS / fallback: load into the main window
                    // Store in pending state so frontend can retrieve it
                    if let Some(state) = _app_handle.try_state::<PendingFile>() {
                        *state.0.lock().unwrap() = Some(path_str.clone());
                    }

                    // Emit to the main window only (not all windows)
                    let _ = _app_handle.emit_to("main", "open-file", &path_str);

                    // Re-emit after delays to handle cold-start timing
                    // The WebView may not have loaded JS listeners yet
                    let handle = _app_handle.clone();
                    let path_for_retry = path_str.clone();
                    std::thread::spawn(move || {
                        for delay_ms in [500, 1500, 3000] {
                            std::thread::sleep(std::time::Duration::from_millis(delay_ms));
                            eprintln!("[file-assoc] re-emit open-file after {}ms", delay_ms);
                            let _ = handle.emit_to("main", "open-file", &path_for_retry);
                        }
                    });
                }
            }
        }
    });
}
