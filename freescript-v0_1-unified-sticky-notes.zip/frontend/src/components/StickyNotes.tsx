/**
 * StickyNotes — the unified Sticky Notes pane ("the Shelf"), ported from
 * FreeScript v5.5 and extended to house OpenDraft's two note systems.
 *
 * Five tabs: Comments / To-Do / Snippets (FreeScript sticky cards: colors,
 * drag-reorder) plus General and Script (OpenDraft's file-level and anchored
 * notes, rendered by GeneralNotesContent / ScriptNotesContent). The 🔍 search
 * spans ALL five tabs at once; clicking a General/Script hit jumps to that
 * tab (Script hits also focus the note via the note filter).
 *
 * Snippets are created from the editor via ⌥⌘X (cut selection to sticky) and
 * ⌥⌘C (copy selection to sticky) — bound in ScreenplayEditor.
 *
 * Sticky cards persist per script as the `_shelf` top-level key of the saved
 * content JSON (same pattern as `_generalNotes`), and sync in collab via
 * collabSync. The active tab persists in view state (`shelfTab`).
 */
import React, { useEffect, useRef, useState } from 'react';
import type { Editor } from '@tiptap/react';
import { useDelayedUnmount, useSwipeDismiss } from '../hooks/useTouch';
import {
  useEditorStore,
  SHELF_COLORS,
  SHELF_DEFAULT_COLOR,
  NOTE_COLORS,
  type ShelfCard,
  type ShelfCardType,
  type ShelfTab,
  type NoteColor,
} from '../stores/editorStore';
import { GeneralNotesContent, ScriptNotesContent } from './ScriptNotes';
import { uuid } from '../utils/uuid';

const TABS: [ShelfTab, string][] = [
  ['comment', 'Comments'],
  ['todo', 'To-Do'],
  ['snippet', 'Snippets'],
  ['general', 'General'],
  ['script', 'Script'],
];

const STICKY_TYPES: ShelfCardType[] = ['comment', 'todo', 'snippet'];

const EMPTY_HINTS: Record<ShelfCardType, string> = {
  comment: 'Notes to self, research links, themes to keep present. Hit + Add below.',
  todo: 'Running checklists that stay out of the Navigator. Hit + Add below.',
  snippet: 'Select text in the Editor and press ⌥⌘X to cut it here, or ⌥⌘C to copy it over.',
};

/** Build a snippet card from editor text (used by the capture shortcuts). */
export function makeSnippetCard(text: string): ShelfCard {
  return { id: uuid(), type: 'snippet', text, color: SHELF_DEFAULT_COLOR };
}

const cardText = (c: ShelfCard): string => {
  if (c.type === 'todo') return (c.items || []).map((i) => i.text).join('\n');
  return c.text || '';
};

const noteColorHex = (name: NoteColor): string => {
  const c = NOTE_COLORS.find((nc) => nc.name === name);
  return c ? c.hex : NOTE_COLORS[0].hex;
};

interface StickyNotesProps {
  editor: Editor | null;
  style?: React.CSSProperties;
}

export default function StickyNotes({ editor, style }: StickyNotesProps) {
  const {
    shelfOpen, toggleShelf, shelfCards, setShelfCards,
    shelfTab: tab, setShelfTab,
    generalNotes, notes, noteFilter, setNoteFilter,
  } = useEditorStore();
  const cards = shelfCards;

  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [dragId, setDragId] = useState<string | null>(null);
  const [startArmed, setStartArmed] = useState(false);
  const [endArmed, setEndArmed] = useState(false);

  const { shouldRender, animationState } = useDelayedUnmount(shelfOpen, 250);
  const panelRef = useRef<HTMLDivElement>(null);
  useSwipeDismiss(panelRef, { direction: 'right', onDismiss: toggleShelf, enabled: shouldRender });

  // When something external (context menu, toolbar, ⌥-click on a highlight)
  // filters to a script note, land on the Script tab.
  useEffect(() => {
    if (noteFilter.noteId || noteFilter.elementType || noteFilter.contextLabel || noteFilter.color) {
      setShelfTab('script');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [noteFilter]);

  if (!shouldRender) return null;

  const panelClass = animationState === 'entered'
    ? 'panel-open' : animationState === 'exiting' ? 'panel-closing' : '';

  const q = query.trim().toLowerCase();
  const searching = searchOpen && q.length > 0;
  const onStickyTab = STICKY_TYPES.includes(tab as ShelfCardType);

  // search spans every tab; otherwise the active tab decides what renders
  const stickyMatches = searching
    ? cards.filter((c) => cardText(c).toLowerCase().includes(q))
    : onStickyTab ? cards.filter((c) => c.type === tab) : [];
  const generalMatches = searching
    ? generalNotes.filter((n) => `${n.title}\n${n.content}`.toLowerCase().includes(q))
    : [];
  const scriptMatches = searching
    ? notes.filter((n) =>
        `${n.content}\n${n.anchorText || ''}\n${n.contextLabel || ''}`.toLowerCase().includes(q))
    : [];
  const totalMatches = stickyMatches.length + generalMatches.length + scriptMatches.length;

  const closeSearch = () => { setQuery(''); setSearchOpen(false); };

  const jumpToGeneral = () => { closeSearch(); setShelfTab('general'); };
  const jumpToScript = (noteId: string) => {
    closeSearch();
    setNoteFilter({ elementType: null, contextLabel: null, color: null, noteId });
    setShelfTab('script');
  };

  const update = (id: string, patch: Partial<ShelfCard>) =>
    setShelfCards(cards.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  const remove = (id: string) => setShelfCards(cards.filter((c) => c.id !== id));
  const add = () => {
    const base: ShelfCard = { id: uuid(), type: tab as ShelfCardType, color: SHELF_DEFAULT_COLOR };
    if (tab === 'comment') base.text = '';
    if (tab === 'todo') base.items = [];
    setShelfCards([...cards, base]);
  };

  const dropOn = (targetId: string) => {
    if (!dragId || dragId === targetId) { setDragId(null); return; }
    const arr = [...cards];
    const from = arr.findIndex((c) => c.id === dragId);
    if (from === -1) { setDragId(null); return; }
    const [moved] = arr.splice(from, 1);
    const to = arr.findIndex((c) => c.id === targetId);
    arr.splice(to === -1 ? arr.length : to, 0, moved);
    setShelfCards(arr);
    setDragId(null);
  };
  const dropAtStart = () => {
    if (!dragId) return;
    const arr = [...cards];
    const from = arr.findIndex((c) => c.id === dragId);
    if (from === -1) { setDragId(null); return; }
    const [moved] = arr.splice(from, 1);
    const firstIdx = arr.findIndex((c) => c.type === tab);
    arr.splice(firstIdx === -1 ? arr.length : firstIdx, 0, moved);
    setShelfCards(arr);
    setDragId(null);
    setStartArmed(false);
  };
  const dropAtEnd = () => {
    if (!dragId) return;
    const arr = [...cards];
    const from = arr.findIndex((c) => c.id === dragId);
    if (from === -1) { setDragId(null); return; }
    const [moved] = arr.splice(from, 1);
    arr.push(moved);
    setShelfCards(arr);
    setDragId(null);
    setEndArmed(false);
  };

  const tabCount = (key: ShelfTab): number => {
    if (key === 'general') return generalNotes.length;
    if (key === 'script') return notes.length;
    return cards.filter((c) => c.type === key).length;
  };

  return (
    <div ref={panelRef} className={`script-notes-panel sticky-notes-panel ${panelClass}`} style={style}>
      <div className="script-notes-header">
        <span className="script-notes-title">Sticky Notes</span>
        <button
          className="swn-search-btn"
          title={searchOpen ? 'Close search' : 'Search all sticky notes'}
          onClick={() => { if (searchOpen) setQuery(''); setSearchOpen((o) => !o); }}
        >{searchOpen ? '✕' : '🔍'}</button>
        <button className="script-notes-close" onClick={toggleShelf} title="Close">
          &times;
        </button>
      </div>

      {searchOpen && (
        <div className="swn-search-row">
          <input
            autoFocus
            value={query}
            placeholder="Search all tabs…"
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      )}

      {!searching && (
        <div className="swn-tabs">
          {TABS.map(([key, label]) => {
            const count = tabCount(key);
            return (
              <button key={key} className={'swn-tab' + (tab === key ? ' active' : '')} onClick={() => setShelfTab(key)}>
                {label}{count > 0 ? ` (${count})` : ''}
              </button>
            );
          })}
        </div>
      )}

      {/* ── Search results: all five tabs at once ── */}
      {searching && (
        <div className="swn-scroll">
          <div className="swn-hint">
            {totalMatches === 0
              ? 'No sticky notes match.'
              : `${totalMatches} match${totalMatches === 1 ? '' : 'es'} across all tabs`}
          </div>
          {stickyMatches.map((card) => (
            <StickyCard
              key={card.id}
              card={card}
              dragging={false}
              onDragStart={() => {}}
              onDragEnd={() => {}}
              onDropHere={() => {}}
              onUpdate={(p) => update(card.id, p)}
              onRemove={() => remove(card.id)}
            />
          ))}
          {generalMatches.length > 0 && <div className="swn-group-label">General Notes</div>}
          {generalMatches.map((gn) => (
            <div
              key={gn.id}
              className="swn-note-hit"
              style={{ borderLeftColor: noteColorHex(gn.color) }}
              onClick={jumpToGeneral}
              title="Open in General tab"
            >
              {gn.title && <div className="swn-note-hit-title">{gn.title}</div>}
              <div className="swn-note-hit-snippet">{gn.content.slice(0, 140) || 'Untitled note'}</div>
            </div>
          ))}
          {scriptMatches.length > 0 && <div className="swn-group-label">Script Notes</div>}
          {scriptMatches.map((n) => (
            <div
              key={n.id}
              className="swn-note-hit"
              style={{ borderLeftColor: noteColorHex(n.color) }}
              onClick={() => jumpToScript(n.id)}
              title="Open in Script tab"
            >
              {n.anchorText && <div className="swn-note-hit-title">&ldquo;{n.anchorText}&rdquo;</div>}
              <div className="swn-note-hit-snippet">{n.content.slice(0, 140) || 'No note text yet'}</div>
            </div>
          ))}
        </div>
      )}

      {/* ── Sticky tabs: cards with drag-reorder ── */}
      {!searching && onStickyTab && (
        <div className="swn-scroll">
          {stickyMatches.length === 0 && (
            <div className="swn-hint">{EMPTY_HINTS[tab as ShelfCardType]}</div>
          )}
          {dragId && stickyMatches.length > 0 && (
            <div
              className={'swn-drop-zone' + (startArmed ? ' armed' : '')}
              onDragOver={(e) => { e.preventDefault(); setStartArmed(true); }}
              onDragLeave={() => setStartArmed(false)}
              onDrop={dropAtStart}
            />
          )}
          {stickyMatches.map((card) => (
            <StickyCard
              key={card.id}
              card={card}
              dragging={dragId === card.id}
              onDragStart={() => setDragId(card.id)}
              onDragEnd={() => { setDragId(null); setStartArmed(false); setEndArmed(false); }}
              onDropHere={() => dropOn(card.id)}
              onUpdate={(p) => update(card.id, p)}
              onRemove={() => remove(card.id)}
            />
          ))}
          {dragId && stickyMatches.length > 0 && (
            <div
              className={'swn-drop-zone' + (endArmed ? ' armed' : '')}
              onDragOver={(e) => { e.preventDefault(); setEndArmed(true); }}
              onDragLeave={() => setEndArmed(false)}
              onDrop={dropAtEnd}
            />
          )}
        </div>
      )}

      {/* ── General / Script tabs: OpenDraft's notes, housed here ── */}
      {!searching && tab === 'general' && <GeneralNotesContent />}
      {!searching && tab === 'script' && <ScriptNotesContent editor={editor} />}

      {!searching && (tab === 'comment' || tab === 'todo') && (
        <div className="swn-add-row">
          <button className="swn-add-btn" onClick={add}>+ Add</button>
        </div>
      )}
    </div>
  );
}

function ColorDots({ card, onUpdate }: { card: ShelfCard; onUpdate: (p: Partial<ShelfCard>) => void }) {
  const [open, setOpen] = useState(false);
  const cur = card.color || SHELF_DEFAULT_COLOR;
  // when open, the trigger dot joins the row: the current color sits rightmost,
  // exactly where the single circle was, and the rest fan out to the LEFT so
  // the row always stays inside the pane
  const ordered = [...SHELF_COLORS.filter(([c]) => c !== cur), ...SHELF_COLORS.filter(([c]) => c === cur)];
  return (
    <span
      className="swn-color-pick"
      onClick={(e) => e.stopPropagation()}
      draggable={false}
      onDragStart={(e) => e.preventDefault()}
    >
      <span
        className="swn-dot"
        style={{ background: cur, visibility: open ? 'hidden' : 'visible' }}
        title="Sticky color"
        onClick={() => setOpen(true)}
      />
      {open && (
        <span className="swn-color-pop" onMouseLeave={() => setOpen(false)}>
          {ordered.map(([c, name]) => (
            <span
              key={c}
              className="swn-dot"
              title={name}
              style={{ background: c, outline: c === cur ? '2px solid #666' : 'none' }}
              onClick={() => { onUpdate({ color: c }); setOpen(false); }}
            />
          ))}
        </span>
      )}
    </span>
  );
}

interface StickyCardProps {
  card: ShelfCard;
  dragging: boolean;
  onDragStart: () => void;
  onDragEnd: () => void;
  onDropHere: () => void;
  onUpdate: (p: Partial<ShelfCard>) => void;
  onRemove: () => void;
}

function StickyCard({ card, dragging, onDragStart, onDragEnd, onDropHere, onUpdate, onRemove }: StickyCardProps) {
  const head = (title: string, extra?: React.ReactNode) => (
    <h5
      className="swn-card-head"
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      title="Drag to reorder"
    >
      <span>⠿ {title}</span>
      <span className="swn-card-actions">
        <ColorDots card={card} onUpdate={onUpdate} />
        {extra}
        <button className="swn-x" title="Delete" onClick={onRemove}>✕</button>
      </span>
    </h5>
  );

  const wrap = (children: React.ReactNode) => (
    <div
      className={'swn-card' + (dragging ? ' dragging' : '')}
      style={{ background: card.color || SHELF_DEFAULT_COLOR }}
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDropHere}
    >
      {children}
    </div>
  );

  if (card.type === 'comment') {
    return wrap(<>
      {head('💬 Comment')}
      <textarea
        className="swn-comment-input"
        value={card.text || ''}
        placeholder="Research links, themes to keep present, notes to self…"
        onChange={(e) => onUpdate({ text: e.target.value })}
      />
    </>);
  }

  if (card.type === 'todo') {
    const items = card.items || [];
    return wrap(<>
      {head('✓ To-Do', (
        <button
          className="swn-x"
          title="Clear completed"
          onClick={() => onUpdate({ items: items.filter((i) => !i.done) })}
        >⌫</button>
      ))}
      {items.map((it, i) => (
        <label key={i} className="swn-todo-item">
          <input
            type="checkbox"
            checked={it.done}
            onChange={() =>
              onUpdate({ items: items.map((x, j) => (j === i ? { ...x, done: !x.done } : x)) })}
          />
          <span style={{ textDecoration: it.done ? 'line-through' : 'none', color: it.done ? '#8a8a7a' : '#333' }}>
            {it.text}
          </span>
        </label>
      ))}
      <input
        className="swn-todo-new"
        placeholder="New to-do…"
        onKeyDown={(e) => {
          const el = e.target as HTMLInputElement;
          if (e.key === 'Enter' && el.value.trim()) {
            onUpdate({ items: [...items, { text: el.value.trim(), done: false }] });
            el.value = '';
          }
        }}
      />
    </>);
  }

  if (card.type === 'snippet') {
    return wrap(<>
      {head('📄 Snippet', (
        <button
          className="swn-x"
          title="Copy to clipboard"
          onClick={() => { if (navigator.clipboard) navigator.clipboard.writeText(card.text || ''); }}
        >⧉</button>
      ))}
      <div className="swn-snippet">{card.text}</div>
    </>);
  }
  return null;
}
