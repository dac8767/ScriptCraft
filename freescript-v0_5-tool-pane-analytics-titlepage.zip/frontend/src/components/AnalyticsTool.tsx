/**
 * AnalyticsTool — script analytics under one roof, as a Tool Panel window:
 *   - Statistics: OpenDraft's full Script Statistics (overview, dialogue,
 *     gender breakdown, scene breakdown, pacing, timing report)
 *   - Gender: the FreeScript Gender Analysis view — parity bars, the
 *     two-plus-female-speakers scene count, and the assignment radio table
 *     (assignments write to Character Profiles)
 */
import { useState } from 'react';
import type { Editor } from '@tiptap/react';
import ScriptStatistics from './ScriptStatistics';
import GenderAnalysisTool from './GenderAnalysisTool';

type AnalyticsTab = 'stats' | 'gender';

interface AnalyticsToolProps {
  editor: Editor | null;
}

export default function AnalyticsTool({ editor }: AnalyticsToolProps) {
  const [tab, setTab] = useState<AnalyticsTab>('stats');

  return (
    <div className="fs-analytics">
      <div className="fs-analytics-tabs">
        <button className={tab === 'stats' ? 'active' : ''} onClick={() => setTab('stats')}>Statistics</button>
        <button className={tab === 'gender' ? 'active' : ''} onClick={() => setTab('gender')}>Gender</button>
      </div>
      {tab === 'stats' && (
        editor
          ? <div className="fs-analytics-stats"><ScriptStatistics editor={editor} embedded /></div>
          : <div className="fs-nav-empty">Open a script to see statistics.</div>
      )}
      {tab === 'gender' && <GenderAnalysisTool editor={editor} />}
    </div>
  );
}
