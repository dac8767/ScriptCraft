/**
 * ToolDock — the left tool column, styled after Photoshop's panel list:
 * a vertical strip of tools (icon + title). Clicking a tool opens a floating
 * window beside the dock where the tool renders; clicking again (or ×) closes
 * it. One tool window is open at a time.
 *
 * Resizing the window (bottom-right handle) saves that size as the tool's
 * default — it reopens at the same size next time (persisted in view state).
 *
 * Tools: Navigator, Scenes, Pages, Structure, Locations (the former left
 * panel views, unchanged inside), Gender Analysis, and Goals — the last three
 * ported from FreeScript v5.5.
 */
import React, { useRef } from 'react';
import type { Editor } from '@tiptap/react';
import {
  FaRegCompass, FaFilm, FaRegClone, FaMapMarkerAlt,
  FaChartBar, FaBullseye,
} from 'react-icons/fa';
import { useEditorStore, type ToolId } from '../stores/editorStore';
import SceneNavigator, { type NavTab } from './SceneNavigator';
import NavigatorTool from './NavigatorTool';
import AnalyticsTool from './AnalyticsTool';
import GoalsTool from './GoalsTool';

interface ToolDef {
  id: ToolId;
  label: string;
  icon: React.ReactNode;
  /** default window size before the user resizes */
  defaultSize: { w: number; h: number };
  /** group separators, Photoshop-style */
  groupStart?: boolean;
}

const TOOLS: ToolDef[] = [
  { id: 'navigator', label: 'Navigator', icon: <FaRegCompass />, defaultSize: { w: 300, h: 520 } },
  { id: 'scenes', label: 'Scenes', icon: <FaFilm />, defaultSize: { w: 320, h: 560 }, groupStart: true },
  { id: 'pages', label: 'Pages', icon: <FaRegClone />, defaultSize: { w: 340, h: 580 } },
  { id: 'locations', label: 'Locations', icon: <FaMapMarkerAlt />, defaultSize: { w: 320, h: 540 } },
  { id: 'analytics', label: 'Analytics', icon: <FaChartBar />, defaultSize: { w: 620, h: 640 }, groupStart: true },
  { id: 'goals', label: 'Goals', icon: <FaBullseye />, defaultSize: { w: 340, h: 440 } },
];

const MIN_W = 240;
const MIN_H = 260;

interface ToolDockProps {
  editor: Editor | null;
  scrollContainer?: HTMLDivElement | null;
}

export default function ToolDock({ editor, scrollContainer }: ToolDockProps) {
  const { activeTool, setActiveTool, toolSizes, setToolSize } = useEditorStore();

  const active = TOOLS.find((t) => t.id === activeTool) || null;
  const size = active
    ? toolSizes[active.id] || active.defaultSize
    : null;

  // ── Resize handling: live-update via CSS vars, persist on pointer-up ──
  const windowRef = useRef<HTMLDivElement>(null);
  const startResize = (e: React.PointerEvent) => {
    if (!active || !windowRef.current) return;
    e.preventDefault();
    const el = windowRef.current;
    const startX = e.clientX;
    const startY = e.clientY;
    const startW = el.offsetWidth;
    const startH = el.offsetHeight;
    let w = startW;
    let h = startH;
    const onMove = (ev: PointerEvent) => {
      w = Math.max(MIN_W, startW + (ev.clientX - startX));
      h = Math.max(MIN_H, startH + (ev.clientY - startY));
      el.style.width = `${w}px`;
      el.style.height = `${h}px`;
    };
    const onUp = () => {
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      // the resized size becomes this tool's default from now on
      setToolSize(active.id, w, h);
    };
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
  };

  const renderTool = (id: ToolId) => {
    switch (id) {
      case 'navigator':
        return <NavigatorTool editor={editor} scrollContainer={scrollContainer} />;
      case 'scenes':
      case 'pages':
      case 'structure':
      case 'locations':
        return <SceneNavigator editor={editor} scrollContainer={scrollContainer} view={id as NavTab} />;
      case 'analytics':
        return <AnalyticsTool editor={editor} />;
      case 'gender': // legacy persisted id — gender now lives inside Analytics
        return <AnalyticsTool editor={editor} />;
      case 'goals':
        return <GoalsTool editor={editor} />;
      default:
        return null;
    }
  };

  return (
    <div className="tool-dock-wrap">
      <div className="tool-dock">
        {TOOLS.map((t) => (
          <React.Fragment key={t.id}>
            {t.groupStart && <div className="tool-dock-sep" />}
            <button
              className={'tool-dock-item' + (activeTool === t.id ? ' active' : '')}
              onClick={() => setActiveTool(activeTool === t.id ? null : t.id)}
              title={t.label}
            >
              <span className="tool-dock-icon">{t.icon}</span>
              <span className="tool-dock-label">{t.label}</span>
            </button>
          </React.Fragment>
        ))}
      </div>

      {active && size && (
        <div
          ref={windowRef}
          className="tool-window"
          style={{ width: size.w, height: size.h }}
        >
          <div className="tool-window-header">
            <span className="tool-window-title">{active.label}</span>
            <button
              className="tool-window-close"
              onClick={() => setActiveTool(null)}
              title="Close"
            >×</button>
          </div>
          <div className="tool-window-body">
            {renderTool(active.id)}
          </div>
          <div
            className="tool-window-resize"
            onPointerDown={startResize}
            title="Drag to resize — the new size becomes this tool's default"
          />
        </div>
      )}
    </div>
  );
}
